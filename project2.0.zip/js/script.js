function burger() {
    $(".header-ul").toggleClass("for_burger");
}